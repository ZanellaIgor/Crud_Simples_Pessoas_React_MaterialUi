
import './App.css';
import NewClient from './clients/new_client/NewClient';




function App() {
  return (
    <div className="App">   
      <NewClient/>
    </div>
  );
}

export default App;
